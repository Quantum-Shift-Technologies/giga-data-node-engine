# Versioning policy

Dataset releases follow semantic versioning: `MAJOR.MINOR.PATCH`.

- **MAJOR:** incompatible schema, identifier or governance change.
- **MINOR:** backward-compatible new fields, tables, areas or seasons.
- **PATCH:** corrected values, metadata, labels or documentation without structural breakage.

Related versions are tracked separately:

- `schema_version` — database and machine-readable schema.
- `processing_version` — transformation or feature-generation code.
- `calculation_version` — agronomic formula configuration.
- `label_version` — annotation taxonomy and guideline.
- `geometry_version` — corrected field or farm geometry.

Raw source files are never silently overwritten. Each processed asset records its input release, processing run, code version and checksum.

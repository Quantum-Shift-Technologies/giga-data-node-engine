# GigaData naming conventions

## Database objects

- Schemas, tables, folders and columns use `lower_snake_case`.
- Table names are plural nouns, for example `weather_observations`.
- Primary keys use `<entity>_id`; foreign keys reuse the referenced key name.
- Boolean fields start with `is_`, `has_` or use an explicit `_status` where multiple states exist.
- Measurement fields include the unit suffix, for example `rainfall_total_mm` and `measured_yield_kg_ha`.
- UTC timestamps end with `_timestamp`; calendar dates end with `_date`.

## Identifier values

- Database primary keys: immutable UUIDs.
- Human-readable business codes: uppercase kebab-case.
- Farmer: `FMR-ZW-ME-000001`
- Farm: `FRM-ZW-ME-000001`
- Field: `FLD-ZW-ME-000001-01`
- Field-season: `FS-2026-27-FLD-ZW-ME-000001-01`
- Weather station: `WX-ZW-ME-001`
- Rover run: `RR-20260715-FLD-ZW-ME-000001-01-001`
- Drone mission: `DM-20260718-FLD-ZW-ME-000001-01-001`

## Files

Use `<subject>_<scope>_<date-or-period>_v<major>_<minor>_<patch>.<extension>`.

Example: `weather_observations_wx_zw_me_001_2026_07_15_v0_1_0.csv`.

File names use lowercase letters, digits and underscores only. Raw files are immutable; a correction creates a new version rather than replacing the original.

# Limitations

All records in this package are synthetic and demonstrate structure only. The sample is too small for statistical analysis or model training.

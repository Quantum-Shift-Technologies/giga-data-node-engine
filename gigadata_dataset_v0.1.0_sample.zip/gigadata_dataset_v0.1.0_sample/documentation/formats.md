# File formats

| Data type | Preferred release format | Representative file |
|---|---|---|
| Tabular raw exchange | CSV UTF-8 | `raw/weather/*.csv` |
| Analytics tables | Parquet in production; CSV included in this sample for easy inspection | `features/*.csv` |
| Vector geometry | GeoJSON / GeoPackage | `processed/geometry/*.geojson` |
| Raster products | Cloud-Optimised GeoTIFF in production; GeoTIFF included here | `processed/drone/*.tif` |
| Metadata/configuration | YAML or JSON | `metadata/*.yaml`, `schema/*.json` |
| Documentation | Markdown | `README.md`, `documentation/*.md` |
| Integrity register | CSV and JSON manifests with SHA-256 | `manifest.csv`, `manifest.json` |

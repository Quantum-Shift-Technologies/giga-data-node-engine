# Identifier standard

| Entity | Internal identifier | Business code |
|---|---|---|
| Farmer | `FMR-ZW-ME-000001` | same pseudonymous code |
| Farm | `6d74ccec-e9d8-5ec3-b6ba-335f7dd935ca` | `FRM-ZW-ME-000001` |
| Field | `1fdd070f-739c-5843-bfc3-5af0a008054f` | `FLD-ZW-ME-000001-01` |
| Field-season | `252cf528-60db-5b21-b8c8-52573cc0617e` | `FS-2026-27-FLD-ZW-ME-000001-01` |
| Crop instance | `dfe1cf94-10a8-5169-bf9c-a0285f2d7eba` | `CRP-FS-2026-27-000001` |
| Weather station | `70bce43f-fbc8-5b1d-bfda-b0f4cd55b0c8` | `WX-ZW-ME-001` |

UUIDs support stable joins and distributed ingestion. Business codes support field operations, troubleshooting and human-readable reports. Neither identifier should be recycled.

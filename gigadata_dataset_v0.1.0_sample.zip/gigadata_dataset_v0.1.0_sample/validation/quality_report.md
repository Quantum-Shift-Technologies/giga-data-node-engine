# Representative sample quality report

- Release: `0.1.0`
- Sample status: **synthetic demonstration data**
- Primary-key checks: PASS
- Foreign-key checks: PASS
- Geometry checks: PASS
- Sensor range checks: PASS
- Calibration checks: PASS
- File checksum checks: PASS
- Rejected records: 0
- Warnings: 0

This report demonstrates the release format. It is not a report on real field collection.

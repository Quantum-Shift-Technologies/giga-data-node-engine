# Representative relationships

`FMR-ZW-ME-000001` → `FRM-ZW-ME-000001` → `FLD-ZW-ME-000001-01` → `FS-2026-27-FLD-ZW-ME-000001-01` → `CRP-FS-2026-27-000001`

The database uses immutable UUID primary keys for farms, fields, field-seasons and observations. Human-readable business codes are retained as separate attributes for field operations and reporting.

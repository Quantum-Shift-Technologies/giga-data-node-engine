-- ============================================================================
-- GigaData Engine Database Schema v2.0
-- Dialect: PostgreSQL 15+ with PostGIS
-- Purpose: Governed, AI-ready agricultural field data platform
--
-- Naming conventions
--   * schemas, tables and columns: lower_snake_case
--   * tables: plural nouns
--   * primary keys: <entity>_id
--   * foreign keys: same name as referenced primary key
--   * timestamps: *_at for timestamp with time zone, *_date for date
--   * percentages: *_pct
--   * distances/areas: unit suffixes such as _m, _km, _m2 and _ha
--
-- This file is a full baseline DDL for a fresh deployment. Use migrations when
-- upgrading an existing database that already contains production data.
-- ============================================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;

-- ============================================================================
-- 1. SCHEMAS
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS metadata;
CREATE SCHEMA IF NOT EXISTS governance;
CREATE SCHEMA IF NOT EXISTS spatial;
CREATE SCHEMA IF NOT EXISTS agronomy;
CREATE SCHEMA IF NOT EXISTS weather;
CREATE SCHEMA IF NOT EXISTS soil;
CREATE SCHEMA IF NOT EXISTS remote_sensing;
CREATE SCHEMA IF NOT EXISTS diagnostics;
CREATE SCHEMA IF NOT EXISTS harvest;
CREATE SCHEMA IF NOT EXISTS quality;
CREATE SCHEMA IF NOT EXISTS features;

-- ============================================================================
-- 2. SHARED METADATA, PROVENANCE, DEVICES AND PROCESSING
-- ============================================================================

CREATE TABLE IF NOT EXISTS metadata.source_registry (
    source_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_name VARCHAR(128) NOT NULL,
    source_type VARCHAR(64) NOT NULL,
    source_owner VARCHAR(128),
    collection_method VARCHAR(128),
    permission_status VARCHAR(32),
    collection_start DATE,
    collection_end DATE,
    spatial_resolution VARCHAR(64),
    temporal_resolution VARCHAR(64),
    licence VARCHAR(128),
    access_tier VARCHAR(32) NOT NULL DEFAULT 'CONTROLLED',
    known_limitations TEXT,
    synthetic_status VARCHAR(32) NOT NULL DEFAULT 'OBSERVED',
    source_version VARCHAR(32),
    contact_or_steward VARCHAR(128),
    quality_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT source_registry_collection_dates_chk
        CHECK (collection_end IS NULL OR collection_start IS NULL OR collection_end >= collection_start),
    CONSTRAINT source_registry_name_version_uq UNIQUE (source_name, source_version)
);

CREATE INDEX IF NOT EXISTS source_registry_type_idx
    ON metadata.source_registry (source_type);
CREATE INDEX IF NOT EXISTS source_registry_access_tier_idx
    ON metadata.source_registry (access_tier);

CREATE TABLE IF NOT EXISTS metadata.devices (
    device_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_type VARCHAR(64) NOT NULL,
    device_owner VARCHAR(128),
    manufacturer_category VARCHAR(128),
    model_category VARCHAR(128),
    serial_number_hash VARCHAR(128) UNIQUE,
    purchase_date DATE,
    deployment_date DATE,
    firmware_version VARCHAR(64),
    measurement_parameters JSONB NOT NULL DEFAULT '[]'::jsonb,
    positioning_method VARCHAR(64),
    stated_accuracy VARCHAR(128),
    device_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    last_service_date DATE,
    next_service_date DATE,
    access_tier VARCHAR(32) NOT NULL DEFAULT 'INTERNAL',
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT devices_service_dates_chk
        CHECK (next_service_date IS NULL OR last_service_date IS NULL OR next_service_date >= last_service_date)
);

CREATE INDEX IF NOT EXISTS devices_type_status_idx
    ON metadata.devices (device_type, device_status);

CREATE TABLE IF NOT EXISTS metadata.sensor_calibrations (
    calibration_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sensor_id UUID REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    device_id UUID REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    calibration_date DATE NOT NULL,
    calibration_method VARCHAR(128),
    calibration_reference VARCHAR(128),
    reference_value DOUBLE PRECISION,
    pre_calibration_error DOUBLE PRECISION,
    post_calibration_error DOUBLE PRECISION,
    correction_factor DOUBLE PRECISION,
    valid_from DATE,
    valid_until DATE,
    calibration_status VARCHAR(32) NOT NULL DEFAULT 'VALID',
    technician_id_hash VARCHAR(128),
    calibration_document_path TEXT,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT sensor_calibrations_device_chk
        CHECK (sensor_id IS NOT NULL OR device_id IS NOT NULL),
    CONSTRAINT sensor_calibrations_validity_chk
        CHECK (valid_until IS NULL OR valid_from IS NULL OR valid_until >= valid_from)
);

CREATE INDEX IF NOT EXISTS sensor_calibrations_sensor_date_idx
    ON metadata.sensor_calibrations (sensor_id, calibration_date DESC);
CREATE INDEX IF NOT EXISTS sensor_calibrations_device_date_idx
    ON metadata.sensor_calibrations (device_id, calibration_date DESC);

CREATE TABLE IF NOT EXISTS metadata.processing_runs (
    processing_run_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    process_name VARCHAR(128) NOT NULL,
    process_type VARCHAR(64) NOT NULL,
    input_dataset_version VARCHAR(64),
    output_dataset_version VARCHAR(64),
    code_version VARCHAR(64),
    parameter_file TEXT,
    start_at TIMESTAMPTZ NOT NULL,
    end_at TIMESTAMPTZ,
    status VARCHAR(32) NOT NULL DEFAULT 'RUNNING',
    records_read BIGINT NOT NULL DEFAULT 0,
    records_written BIGINT NOT NULL DEFAULT 0,
    records_rejected BIGINT NOT NULL DEFAULT 0,
    records_imputed BIGINT NOT NULL DEFAULT 0,
    records_interpolated BIGINT NOT NULL DEFAULT 0,
    operator_id_hash VARCHAR(128),
    log_file_path TEXT,
    quality_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT processing_runs_time_chk CHECK (end_at IS NULL OR end_at >= start_at),
    CONSTRAINT processing_runs_counts_chk CHECK (
        records_read >= 0 AND records_written >= 0 AND records_rejected >= 0
        AND records_imputed >= 0 AND records_interpolated >= 0
    )
);

CREATE INDEX IF NOT EXISTS processing_runs_type_start_idx
    ON metadata.processing_runs (process_type, start_at DESC);

CREATE TABLE IF NOT EXISTS metadata.external_sources (
    external_source_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_name VARCHAR(128) NOT NULL,
    source_type VARCHAR(64) NOT NULL,
    source_owner VARCHAR(128),
    product_name VARCHAR(128),
    product_version VARCHAR(64),
    spatial_resolution_m DOUBLE PRECISION,
    temporal_resolution VARCHAR(64),
    coordinate_reference_system VARCHAR(64),
    access_method VARCHAR(64),
    licence VARCHAR(128),
    permission_status VARCHAR(32),
    collection_start DATE,
    collection_end DATE,
    known_limitations TEXT,
    redistribution_status VARCHAR(32),
    access_tier VARCHAR(32) NOT NULL DEFAULT 'CONTROLLED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT external_sources_dates_chk
        CHECK (collection_end IS NULL OR collection_start IS NULL OR collection_end >= collection_start),
    CONSTRAINT external_sources_product_uq
        UNIQUE (source_name, product_name, product_version)
);

-- ============================================================================
-- 3. GOVERNANCE AND CONSENT
-- ============================================================================

CREATE TABLE IF NOT EXISTS governance.farmers (
    farmer_id VARCHAR(64) PRIMARY KEY,
    gender_code VARCHAR(16),
    age_band VARCHAR(16),
    preferred_language VARCHAR(32) NOT NULL DEFAULT 'English',
    farming_experience_band VARCHAR(32),
    primary_livelihood VARCHAR(64),
    education_band VARCHAR(32),
    extension_access_status VARCHAR(32),
    extension_visit_frequency VARCHAR(32),
    agricultural_credit_access VARCHAR(32),
    agricultural_insurance_status VARCHAR(32),
    market_access_category VARCHAR(32),
    input_access_category VARCHAR(32),
    mechanisation_level VARCHAR(32),
    mobile_access_status VARCHAR(32),
    province_code VARCHAR(8),
    district_code VARCHAR(8),
    ward_code VARCHAR(16),
    consent_version VARCHAR(16),
    consent_status VARCHAR(32) NOT NULL DEFAULT 'VALID',
    registration_date DATE NOT NULL DEFAULT CURRENT_DATE,
    record_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS farmers_location_idx
    ON governance.farmers (province_code, district_code, ward_code);
CREATE INDEX IF NOT EXISTS farmers_consent_status_idx
    ON governance.farmers (consent_status);
CREATE INDEX IF NOT EXISTS farmers_source_id_idx
    ON governance.farmers (source_id);

CREATE TABLE IF NOT EXISTS governance.consent_registry_restricted (
    consent_record_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    farmer_id VARCHAR(64) NOT NULL UNIQUE
        REFERENCES governance.farmers (farmer_id) ON DELETE CASCADE,
    farmer_name VARCHAR(128) NOT NULL,
    phone_number VARCHAR(32) NOT NULL,
    identity_reference VARCHAR(128),
    consent_language VARCHAR(32),
    consent_version VARCHAR(16) NOT NULL DEFAULT '1.0',
    consent_at TIMESTAMPTZ,
    collection_purpose TEXT,
    location_consent_status VARCHAR(32) NOT NULL DEFAULT 'GRANTED',
    image_consent_status VARCHAR(32) NOT NULL DEFAULT 'GRANTED',
    data_sharing_consent_status VARCHAR(32) NOT NULL DEFAULT 'GRANTED',
    withdrawal_receipt_code VARCHAR(64),
    withdrawal_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    withdrawal_date DATE,
    record_access_level VARCHAR(32) NOT NULL DEFAULT 'RESTRICTED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT consent_registry_withdrawal_chk
        CHECK (withdrawal_status <> 'WITHDRAWN' OR withdrawal_date IS NOT NULL)
);

-- ============================================================================
-- 4. SPATIAL REGISTRATION
-- ============================================================================

CREATE TABLE IF NOT EXISTS spatial.farms (
    farm_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    farm_name_code VARCHAR(32),
    farm_centroid geometry(Point, 4326),
    farm_polygon geometry(MultiPolygon, 4326),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    province_code VARCHAR(8),
    district_code VARCHAR(8),
    ward_code VARCHAR(16),
    natural_region VARCHAR(8),
    elevation_m DOUBLE PRECISION,
    total_area_ha DOUBLE PRECISION,
    tenure_type VARCHAR(32),
    farming_system VARCHAR(64),
    water_access_category VARCHAR(32),
    primary_water_source VARCHAR(32),
    road_access_category VARCHAR(32),
    market_distance_km DOUBLE PRECISION,
    polygon_capture_method VARCHAR(32),
    polygon_captured_at TIMESTAMPTZ,
    polygon_capture_device_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    gps_accuracy_m DOUBLE PRECISION,
    coordinate_reference_system VARCHAR(64) NOT NULL DEFAULT 'EPSG:4326',
    geometry_version VARCHAR(32),
    polygon_validation_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    location_access_tier VARCHAR(32) NOT NULL DEFAULT 'CONTROLLED',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT farms_area_chk CHECK (total_area_ha IS NULL OR total_area_ha >= 0),
    CONSTRAINT farms_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT farms_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS farms_polygon_gix
    ON spatial.farms USING GIST (farm_polygon);
CREATE INDEX IF NOT EXISTS farms_centroid_gix
    ON spatial.farms USING GIST (farm_centroid);
CREATE INDEX IF NOT EXISTS farms_location_idx
    ON spatial.farms (province_code, district_code, ward_code);
CREATE INDEX IF NOT EXISTS farms_natural_region_idx
    ON spatial.farms (natural_region);

CREATE TABLE IF NOT EXISTS governance.farmer_farm_roles (
    farmer_farm_role_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    farmer_id VARCHAR(64) NOT NULL
        REFERENCES governance.farmers (farmer_id) ON DELETE CASCADE,
    farm_id UUID NOT NULL
        REFERENCES spatial.farms (farm_id) ON DELETE CASCADE,
    role_code VARCHAR(64) NOT NULL,
    tenure_type VARCHAR(32),
    is_primary_decision_maker BOOLEAN NOT NULL DEFAULT false,
    crop_choice_responsibility BOOLEAN NOT NULL DEFAULT false,
    input_purchase_responsibility BOOLEAN NOT NULL DEFAULT false,
    labour_management_responsibility BOOLEAN NOT NULL DEFAULT false,
    irrigation_responsibility BOOLEAN NOT NULL DEFAULT false,
    marketing_responsibility BOOLEAN NOT NULL DEFAULT false,
    relationship_start_date DATE,
    relationship_end_date DATE,
    verification_status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT farmer_farm_roles_dates_chk
        CHECK (relationship_end_date IS NULL OR relationship_start_date IS NULL OR relationship_end_date >= relationship_start_date),
    CONSTRAINT farmer_farm_roles_uq
        UNIQUE (farmer_id, farm_id, role_code, relationship_start_date)
);

CREATE INDEX IF NOT EXISTS farmer_farm_roles_farmer_idx
    ON governance.farmer_farm_roles (farmer_id);
CREATE INDEX IF NOT EXISTS farmer_farm_roles_farm_idx
    ON governance.farmer_farm_roles (farm_id);
CREATE UNIQUE INDEX IF NOT EXISTS farmer_farm_roles_primary_decision_maker_uq
    ON governance.farmer_farm_roles (farm_id)
    WHERE is_primary_decision_maker = true AND relationship_end_date IS NULL;

CREATE TABLE IF NOT EXISTS spatial.fields (
    field_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    farm_id UUID NOT NULL
        REFERENCES spatial.farms (farm_id) ON DELETE CASCADE,
    field_name_code VARCHAR(32),
    field_polygon geometry(MultiPolygon, 4326),
    field_centroid geometry(Point, 4326),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    area_ha DOUBLE PRECISION,
    perimeter_m DOUBLE PRECISION,
    average_elevation_m DOUBLE PRECISION,
    minimum_elevation_m DOUBLE PRECISION,
    maximum_elevation_m DOUBLE PRECISION,
    average_slope_pct DOUBLE PRECISION,
    aspect_direction VARCHAR(32),
    natural_region VARCHAR(8),
    drainage_class VARCHAR(32),
    irrigation_status VARCHAR(32) NOT NULL DEFAULT 'RAINFED',
    water_source_type VARCHAR(32),
    dominant_soil_texture VARCHAR(32),
    erosion_status VARCHAR(32),
    land_use_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE_PRODUCTION',
    boundary_source VARCHAR(32),
    boundary_captured_at TIMESTAMPTZ,
    boundary_device_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    boundary_accuracy_m DOUBLE PRECISION,
    coordinate_reference_system VARCHAR(64) NOT NULL DEFAULT 'EPSG:4326',
    geometry_version VARCHAR(32),
    polygon_closure_status VARCHAR(32),
    self_intersection_status VARCHAR(32),
    polygon_quality_flag VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    location_access_tier VARCHAR(32) NOT NULL DEFAULT 'CONTROLLED',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT fields_area_chk CHECK (area_ha IS NULL OR area_ha >= 0),
    CONSTRAINT fields_perimeter_chk CHECK (perimeter_m IS NULL OR perimeter_m >= 0),
    CONSTRAINT fields_slope_chk CHECK (average_slope_pct IS NULL OR average_slope_pct >= 0),
    CONSTRAINT fields_elevation_chk CHECK (
        minimum_elevation_m IS NULL OR maximum_elevation_m IS NULL
        OR minimum_elevation_m <= maximum_elevation_m
    ),
    CONSTRAINT fields_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT fields_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180),
    CONSTRAINT fields_name_uq UNIQUE (farm_id, field_name_code)
);

CREATE INDEX IF NOT EXISTS fields_farm_id_idx
    ON spatial.fields (farm_id);
CREATE INDEX IF NOT EXISTS fields_polygon_gix
    ON spatial.fields USING GIST (field_polygon);
CREATE INDEX IF NOT EXISTS fields_centroid_gix
    ON spatial.fields USING GIST (field_centroid);

-- ============================================================================
-- 5. AGRONOMY, SEASONS, CROPS AND MANAGEMENT
-- ============================================================================

CREATE TABLE IF NOT EXISTS agronomy.field_seasons (
    field_season_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_id UUID NOT NULL
        REFERENCES spatial.fields (field_id) ON DELETE CASCADE,
    season_id VARCHAR(16) NOT NULL,
    season_start_date DATE,
    season_end_date DATE,
    season_status VARCHAR(32) NOT NULL DEFAULT 'PLANNED',
    primary_crop_code VARCHAR(64),
    primary_variety_code VARCHAR(64),
    planting_date DATE,
    expected_emergence_date DATE,
    expected_flowering_date DATE,
    expected_harvest_date DATE,
    actual_harvest_date DATE,
    irrigation_status VARCHAR(32),
    crop_change_status VARCHAR(32),
    crop_change_reason VARCHAR(128),
    previous_season_crop VARCHAR(64),
    previous_season_yield_kg_ha DOUBLE PRECISION,
    previous_season_status VARCHAR(32),
    record_completeness_pct DOUBLE PRECISION NOT NULL DEFAULT 0,
    overall_confidence_score DOUBLE PRECISION,
    uncertainty_flags JSONB NOT NULL DEFAULT '[]'::jsonb,
    release_version VARCHAR(32),
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT field_seasons_dates_chk CHECK (
        season_end_date IS NULL OR season_start_date IS NULL OR season_end_date >= season_start_date
    ),
    CONSTRAINT field_seasons_plant_harvest_chk CHECK (
        actual_harvest_date IS NULL OR planting_date IS NULL OR actual_harvest_date >= planting_date
    ),
    CONSTRAINT field_seasons_completeness_chk CHECK (record_completeness_pct BETWEEN 0 AND 100),
    CONSTRAINT field_seasons_confidence_chk CHECK (
        overall_confidence_score IS NULL OR overall_confidence_score BETWEEN 0 AND 1
    ),
    CONSTRAINT field_seasons_field_season_uq UNIQUE (field_id, season_id)
);

CREATE INDEX IF NOT EXISTS field_seasons_field_id_idx
    ON agronomy.field_seasons (field_id);
CREATE INDEX IF NOT EXISTS field_seasons_season_id_idx
    ON agronomy.field_seasons (season_id);
CREATE INDEX IF NOT EXISTS field_seasons_crop_code_idx
    ON agronomy.field_seasons (primary_crop_code);
CREATE INDEX IF NOT EXISTS field_seasons_status_idx
    ON agronomy.field_seasons (season_status);

CREATE TABLE IF NOT EXISTS spatial.spatial_units (
    spatial_unit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    parent_spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE CASCADE,
    spatial_unit_type VARCHAR(32) NOT NULL,
    geometry geometry(MultiPolygon, 4326),
    centroid geometry(Point, 4326),
    area_m2 DOUBLE PRECISION,
    grid_resolution_m DOUBLE PRECISION,
    management_zone_code VARCHAR(32),
    coordinate_reference_system VARCHAR(64) NOT NULL DEFAULT 'EPSG:4326',
    geometry_source VARCHAR(64),
    geometry_accuracy_m DOUBLE PRECISION,
    geometry_version VARCHAR(32),
    valid_from DATE,
    valid_to DATE,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT spatial_units_area_chk CHECK (area_m2 IS NULL OR area_m2 >= 0),
    CONSTRAINT spatial_units_validity_chk CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from)
);

CREATE INDEX IF NOT EXISTS spatial_units_field_season_idx
    ON spatial.spatial_units (field_season_id);
CREATE INDEX IF NOT EXISTS spatial_units_parent_idx
    ON spatial.spatial_units (parent_spatial_unit_id);
CREATE INDEX IF NOT EXISTS spatial_units_geometry_gix
    ON spatial.spatial_units USING GIST (geometry);

CREATE TABLE IF NOT EXISTS agronomy.crop_instances (
    crop_instance_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    crop_code VARCHAR(64) NOT NULL,
    variety_code VARCHAR(64),
    variety_category VARCHAR(64),
    crop_role VARCHAR(32) NOT NULL DEFAULT 'PRIMARY',
    planted_area_ha DOUBLE PRECISION,
    planting_date DATE,
    planting_method VARCHAR(64),
    seed_source VARCHAR(64),
    seed_rate_kg_ha DOUBLE PRECISION,
    target_plant_density_ha DOUBLE PRECISION,
    row_spacing_cm DOUBLE PRECISION,
    plant_spacing_cm DOUBLE PRECISION,
    previous_crop_code VARCHAR(64),
    intercrop_crop_code VARCHAR(64),
    expected_maturity_days INTEGER,
    crop_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT crop_instances_area_chk CHECK (planted_area_ha IS NULL OR planted_area_ha >= 0),
    CONSTRAINT crop_instances_seed_rate_chk CHECK (seed_rate_kg_ha IS NULL OR seed_rate_kg_ha >= 0),
    CONSTRAINT crop_instances_maturity_chk CHECK (expected_maturity_days IS NULL OR expected_maturity_days > 0)
);

CREATE INDEX IF NOT EXISTS crop_instances_field_season_idx
    ON agronomy.crop_instances (field_season_id);
CREATE INDEX IF NOT EXISTS crop_instances_spatial_unit_idx
    ON agronomy.crop_instances (spatial_unit_id);
CREATE INDEX IF NOT EXISTS crop_instances_crop_code_idx
    ON agronomy.crop_instances (crop_code);

CREATE TABLE IF NOT EXISTS agronomy.crop_history (
    crop_history_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_id UUID NOT NULL
        REFERENCES spatial.fields (field_id) ON DELETE CASCADE,
    historical_season_id VARCHAR(16) NOT NULL,
    crop_code VARCHAR(64) NOT NULL,
    variety_code VARCHAR(64),
    planting_date_estimated DATE,
    harvest_date_estimated DATE,
    irrigation_status VARCHAR(32),
    yield_reported_kg_ha DOUBLE PRECISION,
    crop_outcome VARCHAR(32),
    crop_change_from_previous BOOLEAN,
    crop_change_reason VARCHAR(128),
    history_source VARCHAR(64),
    recall_confidence DOUBLE PRECISION,
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT crop_history_dates_chk CHECK (
        harvest_date_estimated IS NULL OR planting_date_estimated IS NULL
        OR harvest_date_estimated >= planting_date_estimated
    ),
    CONSTRAINT crop_history_confidence_chk CHECK (
        recall_confidence IS NULL OR recall_confidence BETWEEN 0 AND 1
    )
);

CREATE INDEX IF NOT EXISTS crop_history_field_season_idx
    ON agronomy.crop_history (field_id, historical_season_id);

CREATE TABLE IF NOT EXISTS agronomy.management_events (
    management_event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    crop_instance_id UUID
        REFERENCES agronomy.crop_instances (crop_instance_id) ON DELETE SET NULL,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    event_type VARCHAR(64) NOT NULL,
    event_at TIMESTAMPTZ,
    event_date DATE,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    event_geometry geometry(Geometry, 4326),
    gps_accuracy_m DOUBLE PRECISION,
    input_category VARCHAR(64),
    input_product_generic VARCHAR(128),
    input_form VARCHAR(64),
    quantity DOUBLE PRECISION,
    unit VARCHAR(32),
    application_rate DOUBLE PRECISION,
    application_method VARCHAR(64),
    estimated_cost_usd NUMERIC(14, 2),
    labour_type VARCHAR(64),
    equipment_type VARCHAR(64),
    reason_for_application TEXT,
    management_timing_status VARCHAR(32),
    source_type VARCHAR(64),
    verification_status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT management_events_time_chk CHECK (event_at IS NOT NULL OR event_date IS NOT NULL),
    CONSTRAINT management_events_quantity_chk CHECK (quantity IS NULL OR quantity >= 0),
    CONSTRAINT management_events_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT management_events_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS management_events_field_season_date_idx
    ON agronomy.management_events (field_season_id, event_date);
CREATE INDEX IF NOT EXISTS management_events_crop_instance_idx
    ON agronomy.management_events (crop_instance_id);
CREATE INDEX IF NOT EXISTS management_events_geometry_gix
    ON agronomy.management_events USING GIST (event_geometry);

-- ============================================================================
-- 6. WEATHER AND AGROCLIMATE
-- ============================================================================

CREATE TABLE IF NOT EXISTS weather.weather_stations (
    weather_station_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    station_name VARCHAR(128) NOT NULL,
    station_owner VARCHAR(128),
    station_type VARCHAR(64) NOT NULL,
    installation_date DATE,
    decommission_date DATE,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    altitude_m DOUBLE PRECISION,
    location_geometry geometry(Point, 4326),
    coordinate_reference_system VARCHAR(64) NOT NULL DEFAULT 'EPSG:4326',
    gps_accuracy_m DOUBLE PRECISION,
    province_code VARCHAR(8),
    district_code VARCHAR(8),
    ward_code VARCHAR(16),
    natural_region VARCHAR(8),
    site_description TEXT,
    ground_surface_type VARCHAR(64),
    surrounding_land_cover VARCHAR(64),
    power_source VARCHAR(64),
    connectivity_type VARCHAR(64),
    transmission_interval_minutes INTEGER,
    data_logger_type VARCHAR(64),
    station_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    data_access_tier VARCHAR(32) NOT NULL DEFAULT 'CONTROLLED',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT weather_stations_dates_chk
        CHECK (decommission_date IS NULL OR installation_date IS NULL OR decommission_date >= installation_date),
    CONSTRAINT weather_stations_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT weather_stations_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180),
    CONSTRAINT weather_stations_interval_chk
        CHECK (transmission_interval_minutes IS NULL OR transmission_interval_minutes > 0)
);

CREATE INDEX IF NOT EXISTS weather_stations_location_gix
    ON weather.weather_stations USING GIST (location_geometry);
CREATE INDEX IF NOT EXISTS weather_stations_location_idx
    ON weather.weather_stations (province_code, district_code, ward_code);
CREATE INDEX IF NOT EXISTS weather_stations_status_idx
    ON weather.weather_stations (station_status);

CREATE TABLE IF NOT EXISTS weather.weather_station_sensors (
    station_sensor_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    weather_station_id UUID NOT NULL
        REFERENCES weather.weather_stations (weather_station_id) ON DELETE CASCADE,
    sensor_id UUID NOT NULL
        REFERENCES metadata.devices (device_id) ON DELETE RESTRICT,
    parameter_code VARCHAR(64) NOT NULL,
    manufacturer_category VARCHAR(128),
    model_category VARCHAR(128),
    serial_number_hash VARCHAR(128),
    measurement_unit VARCHAR(32) NOT NULL,
    sensor_height_m DOUBLE PRECISION,
    measurement_depth_cm DOUBLE PRECISION,
    measurement_interval_minutes INTEGER,
    stated_accuracy VARCHAR(128),
    minimum_valid_value DOUBLE PRECISION,
    maximum_valid_value DOUBLE PRECISION,
    installation_date DATE,
    last_calibration_date DATE,
    next_calibration_date DATE,
    sensor_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT weather_station_sensors_range_chk CHECK (
        minimum_valid_value IS NULL OR maximum_valid_value IS NULL
        OR minimum_valid_value <= maximum_valid_value
    ),
    CONSTRAINT weather_station_sensors_interval_chk
        CHECK (measurement_interval_minutes IS NULL OR measurement_interval_minutes > 0),
    CONSTRAINT weather_station_sensors_uq
        UNIQUE (weather_station_id, sensor_id, parameter_code)
);

CREATE INDEX IF NOT EXISTS weather_station_sensors_station_idx
    ON weather.weather_station_sensors (weather_station_id);
CREATE INDEX IF NOT EXISTS weather_station_sensors_parameter_idx
    ON weather.weather_station_sensors (parameter_code);

CREATE TABLE IF NOT EXISTS weather.weather_observations (
    weather_observation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    weather_station_id UUID NOT NULL
        REFERENCES weather.weather_stations (weather_station_id) ON DELETE CASCADE,
    station_sensor_id UUID NOT NULL
        REFERENCES weather.weather_station_sensors (station_sensor_id) ON DELETE CASCADE,
    observation_at TIMESTAMPTZ NOT NULL,
    parameter_code VARCHAR(64) NOT NULL,
    raw_value DOUBLE PRECISION,
    calibrated_value DOUBLE PRECISION,
    unit VARCHAR(32) NOT NULL,
    battery_voltage DOUBLE PRECISION,
    signal_strength DOUBLE PRECISION,
    sensor_status VARCHAR(32),
    calibration_status VARCHAR(32),
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    uncertainty_value DOUBLE PRECISION,
    received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    source_type VARCHAR(64),
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT weather_observations_value_chk
        CHECK (raw_value IS NOT NULL OR calibrated_value IS NOT NULL),
    CONSTRAINT weather_observations_uq
        UNIQUE (station_sensor_id, observation_at, parameter_code)
);

CREATE INDEX IF NOT EXISTS weather_observations_station_time_idx
    ON weather.weather_observations (weather_station_id, observation_at DESC);
CREATE INDEX IF NOT EXISTS weather_observations_sensor_time_idx
    ON weather.weather_observations (station_sensor_id, observation_at DESC);
CREATE INDEX IF NOT EXISTS weather_observations_parameter_time_idx
    ON weather.weather_observations (parameter_code, observation_at DESC);

CREATE TABLE IF NOT EXISTS weather.weather_hourly_summaries (
    weather_station_id UUID NOT NULL
        REFERENCES weather.weather_stations (weather_station_id) ON DELETE CASCADE,
    observation_hour TIMESTAMPTZ NOT NULL,
    temperature_min_c DOUBLE PRECISION,
    temperature_max_c DOUBLE PRECISION,
    temperature_mean_c DOUBLE PRECISION,
    relative_humidity_min_pct DOUBLE PRECISION,
    relative_humidity_max_pct DOUBLE PRECISION,
    relative_humidity_mean_pct DOUBLE PRECISION,
    rainfall_total_mm DOUBLE PRECISION,
    wind_speed_mean_m_s DOUBLE PRECISION,
    wind_gust_max_m_s DOUBLE PRECISION,
    wind_direction_mean_deg DOUBLE PRECISION,
    solar_radiation_mean_w_m2 DOUBLE PRECISION,
    solar_energy_mj_m2_hour DOUBLE PRECISION,
    atmospheric_pressure_mean_hpa DOUBLE PRECISION,
    leaf_wetness_minutes DOUBLE PRECISION,
    sunshine_duration_minutes DOUBLE PRECISION,
    uv_index_mean DOUBLE PRECISION,
    uv_index_max DOUBLE PRECISION,
    valid_reading_pct DOUBLE PRECISION,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (weather_station_id, observation_hour),
    CONSTRAINT weather_hourly_temperature_chk
        CHECK (temperature_min_c IS NULL OR temperature_max_c IS NULL OR temperature_min_c <= temperature_max_c),
    CONSTRAINT weather_hourly_humidity_chk CHECK (
        (relative_humidity_min_pct IS NULL OR relative_humidity_min_pct BETWEEN 0 AND 100)
        AND (relative_humidity_max_pct IS NULL OR relative_humidity_max_pct BETWEEN 0 AND 100)
        AND (relative_humidity_mean_pct IS NULL OR relative_humidity_mean_pct BETWEEN 0 AND 100)
    ),
    CONSTRAINT weather_hourly_valid_pct_chk
        CHECK (valid_reading_pct IS NULL OR valid_reading_pct BETWEEN 0 AND 100)
);

CREATE TABLE IF NOT EXISTS weather.weather_daily_summaries (
    weather_station_id UUID NOT NULL
        REFERENCES weather.weather_stations (weather_station_id) ON DELETE CASCADE,
    observation_date DATE NOT NULL,
    temperature_min_c DOUBLE PRECISION,
    temperature_max_c DOUBLE PRECISION,
    temperature_mean_c DOUBLE PRECISION,
    relative_humidity_min_pct DOUBLE PRECISION,
    relative_humidity_max_pct DOUBLE PRECISION,
    relative_humidity_mean_pct DOUBLE PRECISION,
    rainfall_total_mm DOUBLE PRECISION,
    wind_speed_mean_m_s DOUBLE PRECISION,
    wind_gust_max_m_s DOUBLE PRECISION,
    wind_direction_mean_deg DOUBLE PRECISION,
    solar_energy_mj_m2_day DOUBLE PRECISION,
    sunshine_duration_hours DOUBLE PRECISION,
    leaf_wetness_duration_hours DOUBLE PRECISION,
    uv_index_mean DOUBLE PRECISION,
    uv_index_max DOUBLE PRECISION,
    atmospheric_pressure_mean_hpa DOUBLE PRECISION,
    valid_observation_pct DOUBLE PRECISION,
    missing_observation_pct DOUBLE PRECISION,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (weather_station_id, observation_date),
    CONSTRAINT weather_daily_temperature_chk
        CHECK (temperature_min_c IS NULL OR temperature_max_c IS NULL OR temperature_min_c <= temperature_max_c),
    CONSTRAINT weather_daily_valid_pct_chk
        CHECK (valid_observation_pct IS NULL OR valid_observation_pct BETWEEN 0 AND 100),
    CONSTRAINT weather_daily_missing_pct_chk
        CHECK (missing_observation_pct IS NULL OR missing_observation_pct BETWEEN 0 AND 100)
);

CREATE TABLE IF NOT EXISTS weather.field_weather_links (
    field_weather_link_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_id UUID NOT NULL
        REFERENCES spatial.fields (field_id) ON DELETE CASCADE,
    field_season_id UUID
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    weather_station_id UUID NOT NULL
        REFERENCES weather.weather_stations (weather_station_id) ON DELETE CASCADE,
    distance_to_field_centroid_m DOUBLE PRECISION,
    elevation_difference_m DOUBLE PRECISION,
    station_inside_field BOOLEAN,
    station_inside_farm BOOLEAN,
    assignment_method VARCHAR(64) NOT NULL,
    assignment_weight DOUBLE PRECISION,
    valid_from DATE,
    valid_to DATE,
    season_coverage_pct DOUBLE PRECISION,
    missing_period_count INTEGER NOT NULL DEFAULT 0,
    link_quality_score DOUBLE PRECISION,
    fallback_source_id UUID
        REFERENCES metadata.external_sources (external_source_id) ON DELETE SET NULL,
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT field_weather_links_validity_chk
        CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from),
    CONSTRAINT field_weather_links_weight_chk
        CHECK (assignment_weight IS NULL OR assignment_weight BETWEEN 0 AND 1),
    CONSTRAINT field_weather_links_coverage_chk
        CHECK (season_coverage_pct IS NULL OR season_coverage_pct BETWEEN 0 AND 100),
    CONSTRAINT field_weather_links_quality_chk
        CHECK (link_quality_score IS NULL OR link_quality_score BETWEEN 0 AND 1)
);

CREATE INDEX IF NOT EXISTS field_weather_links_field_season_idx
    ON weather.field_weather_links (field_season_id);
CREATE INDEX IF NOT EXISTS field_weather_links_station_idx
    ON weather.field_weather_links (weather_station_id);

CREATE TABLE IF NOT EXISTS weather.agroclimate_features (
    agroclimate_feature_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    crop_instance_id UUID
        REFERENCES agronomy.crop_instances (crop_instance_id) ON DELETE SET NULL,
    observation_date DATE NOT NULL,
    weather_source_id UUID
        REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    weather_assignment_method VARCHAR(64),
    gdd_base_temperature_c DOUBLE PRECISION,
    gdd_upper_cap_c DOUBLE PRECISION,
    daily_gdd DOUBLE PRECISION,
    cumulative_gdd_from_planting DOUBLE PRECISION,
    rainfall_daily_mm DOUBLE PRECISION,
    rainfall_since_planting_mm DOUBLE PRECISION,
    consecutive_dry_days INTEGER,
    maximum_dry_spell_days INTEGER,
    rainy_day_count INTEGER,
    heat_stress_hours DOUBLE PRECISION,
    heat_stress_days INTEGER,
    cold_stress_hours DOUBLE PRECISION,
    cold_stress_days INTEGER,
    reference_et_mm DOUBLE PRECISION,
    cumulative_reference_et_mm DOUBLE PRECISION,
    estimated_crop_et_mm DOUBLE PRECISION,
    water_balance_daily_mm DOUBLE PRECISION,
    cumulative_water_balance_mm DOUBLE PRECISION,
    vapour_pressure_deficit_kpa DOUBLE PRECISION,
    relative_humidity_mean_pct DOUBLE PRECISION,
    leaf_wetness_duration_hours DOUBLE PRECISION,
    solar_radiation_daily_mj_m2 DOUBLE PRECISION,
    cumulative_solar_radiation_mj_m2 DOUBLE PRECISION,
    sunshine_duration_hours DOUBLE PRECISION,
    uv_index_mean DOUBLE PRECISION,
    uv_index_max DOUBLE PRECISION,
    uv_dose_estimate DOUBLE PRECISION,
    disease_weather_risk_score DOUBLE PRECISION,
    calculation_version VARCHAR(64),
    processing_run_id UUID
        REFERENCES metadata.processing_runs (processing_run_id) ON DELETE SET NULL,
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT agroclimate_features_humidity_chk
        CHECK (relative_humidity_mean_pct IS NULL OR relative_humidity_mean_pct BETWEEN 0 AND 100),
    CONSTRAINT agroclimate_features_risk_chk
        CHECK (disease_weather_risk_score IS NULL OR disease_weather_risk_score BETWEEN 0 AND 1),
    CONSTRAINT agroclimate_features_uq
        UNIQUE (field_season_id, crop_instance_id, observation_date, calculation_version)
);

CREATE INDEX IF NOT EXISTS agroclimate_features_field_date_idx
    ON weather.agroclimate_features (field_season_id, observation_date);

-- ============================================================================
-- 7. SOIL ROVER DATA AND SOIL SURFACE PRODUCTS
-- ============================================================================

CREATE TABLE IF NOT EXISTS soil.rover_runs (
    rover_run_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    field_id UUID NOT NULL
        REFERENCES spatial.fields (field_id) ON DELETE CASCADE,
    rover_id UUID NOT NULL
        REFERENCES metadata.devices (device_id) ON DELETE RESTRICT,
    operator_id_hash VARCHAR(128),
    run_start_at TIMESTAMPTZ NOT NULL,
    run_end_at TIMESTAMPTZ,
    rover_track geometry(LineString, 4326),
    sampling_pattern VARCHAR(32),
    sampling_interval_m DOUBLE PRECISION,
    target_measurement_depth_cm DOUBLE PRECISION,
    distance_covered_m DOUBLE PRECISION,
    area_covered_ha DOUBLE PRECISION,
    field_coverage_pct DOUBLE PRECISION,
    positioning_method VARCHAR(64),
    average_gps_accuracy_m DOUBLE PRECISION,
    sensor_calibration_status VARCHAR(32),
    weather_conditions VARCHAR(128),
    run_quality_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT rover_runs_time_chk CHECK (run_end_at IS NULL OR run_end_at >= run_start_at),
    CONSTRAINT rover_runs_coverage_chk
        CHECK (field_coverage_pct IS NULL OR field_coverage_pct BETWEEN 0 AND 100)
);

CREATE INDEX IF NOT EXISTS rover_runs_field_season_idx
    ON soil.rover_runs (field_season_id);
CREATE INDEX IF NOT EXISTS rover_runs_field_idx
    ON soil.rover_runs (field_id);
CREATE INDEX IF NOT EXISTS rover_runs_track_gix
    ON soil.rover_runs USING GIST (rover_track);

CREATE TABLE IF NOT EXISTS soil.rover_measurements (
    rover_measurement_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rover_run_id UUID NOT NULL
        REFERENCES soil.rover_runs (rover_run_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    measurement_at TIMESTAMPTZ NOT NULL,
    measurement_point geometry(Point, 4326),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    altitude_m DOUBLE PRECISION,
    gps_accuracy_m DOUBLE PRECISION,
    measurement_depth_cm DOUBLE PRECISION,
    parameter_code VARCHAR(64) NOT NULL,
    raw_value DOUBLE PRECISION,
    calibrated_value DOUBLE PRECISION,
    validated_value DOUBLE PRECISION,
    unit VARCHAR(32) NOT NULL,
    sensor_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    sensor_accuracy VARCHAR(128),
    calibration_date DATE,
    calibration_status VARCHAR(32),
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    uncertainty_value DOUBLE PRECISION,
    rejection_reason TEXT,
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT rover_measurements_value_chk CHECK (
        raw_value IS NOT NULL OR calibrated_value IS NOT NULL OR validated_value IS NOT NULL
    ),
    CONSTRAINT rover_measurements_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT rover_measurements_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS rover_measurements_run_time_idx
    ON soil.rover_measurements (rover_run_id, measurement_at);
CREATE INDEX IF NOT EXISTS rover_measurements_field_parameter_idx
    ON soil.rover_measurements (field_season_id, parameter_code, measurement_at);
CREATE INDEX IF NOT EXISTS rover_measurements_point_gix
    ON soil.rover_measurements USING GIST (measurement_point);

CREATE TABLE IF NOT EXISTS soil.soil_surface_products (
    soil_surface_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rover_run_id UUID NOT NULL
        REFERENCES soil.rover_runs (rover_run_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    parameter_code VARCHAR(64) NOT NULL,
    file_path TEXT NOT NULL,
    uncertainty_surface_path TEXT,
    cell_resolution_m DOUBLE PRECISION,
    interpolation_method VARCHAR(64),
    input_point_count INTEGER,
    minimum_value DOUBLE PRECISION,
    maximum_value DOUBLE PRECISION,
    mean_value DOUBLE PRECISION,
    standard_deviation DOUBLE PRECISION,
    cross_validation_rmse DOUBLE PRECISION,
    coordinate_reference_system VARCHAR(64),
    processed_at TIMESTAMPTZ,
    processing_version VARCHAR(64),
    processing_run_id UUID
        REFERENCES metadata.processing_runs (processing_run_id) ON DELETE SET NULL,
    validation_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    checksum_sha256 CHAR(64),
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT soil_surface_products_range_chk
        CHECK (minimum_value IS NULL OR maximum_value IS NULL OR minimum_value <= maximum_value),
    CONSTRAINT soil_surface_products_points_chk
        CHECK (input_point_count IS NULL OR input_point_count >= 0),
    CONSTRAINT soil_surface_products_uq
        UNIQUE (rover_run_id, parameter_code, processing_version)
);

CREATE INDEX IF NOT EXISTS soil_surface_products_field_parameter_idx
    ON soil.soil_surface_products (field_season_id, parameter_code);

-- ============================================================================
-- 8. DRONE AND EXTERNAL REMOTE-SENSING DATA
-- ============================================================================

CREATE TABLE IF NOT EXISTS remote_sensing.drone_missions (
    drone_mission_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    field_id UUID NOT NULL
        REFERENCES spatial.fields (field_id) ON DELETE CASCADE,
    drone_id UUID NOT NULL
        REFERENCES metadata.devices (device_id) ON DELETE RESTRICT,
    multispectral_sensor_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    operator_id_hash VARCHAR(128),
    mission_stage VARCHAR(32),
    mission_start_at TIMESTAMPTZ NOT NULL,
    mission_end_at TIMESTAMPTZ,
    flight_boundary geometry(MultiPolygon, 4326),
    takeoff_location geometry(Point, 4326),
    landing_location geometry(Point, 4326),
    flight_altitude_m DOUBLE PRECISION,
    ground_sampling_distance_cm DOUBLE PRECISION,
    forward_overlap_pct DOUBLE PRECISION,
    side_overlap_pct DOUBLE PRECISION,
    flight_speed_m_s DOUBLE PRECISION,
    reflectance_panel_used BOOLEAN,
    irradiance_calibration_status VARCHAR(32),
    weather_station_id UUID
        REFERENCES weather.weather_stations (weather_station_id) ON DELETE SET NULL,
    wind_speed_at_flight_m_s DOUBLE PRECISION,
    cloud_cover_pct DOUBLE PRECISION,
    weather_conditions VARCHAR(128),
    field_coverage_pct DOUBLE PRECISION,
    positioning_method VARCHAR(64),
    average_gps_accuracy_m DOUBLE PRECISION,
    mission_quality_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT drone_missions_time_chk CHECK (mission_end_at IS NULL OR mission_end_at >= mission_start_at),
    CONSTRAINT drone_missions_forward_overlap_chk
        CHECK (forward_overlap_pct IS NULL OR forward_overlap_pct BETWEEN 0 AND 100),
    CONSTRAINT drone_missions_side_overlap_chk
        CHECK (side_overlap_pct IS NULL OR side_overlap_pct BETWEEN 0 AND 100),
    CONSTRAINT drone_missions_cloud_chk
        CHECK (cloud_cover_pct IS NULL OR cloud_cover_pct BETWEEN 0 AND 100),
    CONSTRAINT drone_missions_coverage_chk
        CHECK (field_coverage_pct IS NULL OR field_coverage_pct BETWEEN 0 AND 100)
);

CREATE INDEX IF NOT EXISTS drone_missions_field_season_idx
    ON remote_sensing.drone_missions (field_season_id, mission_start_at);
CREATE INDEX IF NOT EXISTS drone_missions_boundary_gix
    ON remote_sensing.drone_missions USING GIST (flight_boundary);

CREATE TABLE IF NOT EXISTS remote_sensing.drone_raw_assets (
    drone_asset_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    drone_mission_id UUID NOT NULL
        REFERENCES remote_sensing.drone_missions (drone_mission_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    captured_at TIMESTAMPTZ NOT NULL,
    image_centre_point geometry(Point, 4326),
    image_footprint geometry(Polygon, 4326),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    altitude_m DOUBLE PRECISION,
    gps_accuracy_m DOUBLE PRECISION,
    camera_heading_deg DOUBLE PRECISION,
    camera_pitch_deg DOUBLE PRECISION,
    camera_roll_deg DOUBLE PRECISION,
    band_code VARCHAR(32) NOT NULL,
    file_path TEXT NOT NULL,
    file_format VARCHAR(32),
    image_width_px INTEGER,
    image_height_px INTEGER,
    radiometric_calibration_status VARCHAR(32),
    image_quality_flag VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    checksum_sha256 CHAR(64),
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT drone_raw_assets_dimensions_chk CHECK (
        (image_width_px IS NULL OR image_width_px > 0)
        AND (image_height_px IS NULL OR image_height_px > 0)
    )
);

CREATE INDEX IF NOT EXISTS drone_raw_assets_mission_time_idx
    ON remote_sensing.drone_raw_assets (drone_mission_id, captured_at);
CREATE INDEX IF NOT EXISTS drone_raw_assets_centre_gix
    ON remote_sensing.drone_raw_assets USING GIST (image_centre_point);

CREATE TABLE IF NOT EXISTS remote_sensing.drone_products (
    drone_product_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    drone_mission_id UUID NOT NULL
        REFERENCES remote_sensing.drone_missions (drone_mission_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    product_type VARCHAR(64) NOT NULL,
    index_code VARCHAR(32),
    file_path TEXT NOT NULL,
    spatial_resolution_cm DOUBLE PRECISION,
    coordinate_reference_system VARCHAR(64),
    processing_method VARCHAR(128),
    processing_software VARCHAR(128),
    processing_version VARCHAR(64),
    formula_version VARCHAR(64),
    input_bands JSONB NOT NULL DEFAULT '[]'::jsonb,
    valid_pixel_pct DOUBLE PRECISION,
    masked_pixel_pct DOUBLE PRECISION,
    cloud_shadow_mask_path TEXT,
    processed_at TIMESTAMPTZ,
    validation_status VARCHAR(32) NOT NULL DEFAULT 'UNVERIFIED',
    uncertainty_score DOUBLE PRECISION,
    processing_run_id UUID
        REFERENCES metadata.processing_runs (processing_run_id) ON DELETE SET NULL,
    checksum_sha256 CHAR(64),
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT drone_products_valid_pixel_chk
        CHECK (valid_pixel_pct IS NULL OR valid_pixel_pct BETWEEN 0 AND 100),
    CONSTRAINT drone_products_masked_pixel_chk
        CHECK (masked_pixel_pct IS NULL OR masked_pixel_pct BETWEEN 0 AND 100),
    CONSTRAINT drone_products_uncertainty_chk
        CHECK (uncertainty_score IS NULL OR uncertainty_score BETWEEN 0 AND 1),
    CONSTRAINT drone_products_uq
        UNIQUE (drone_mission_id, product_type, index_code, processing_version)
);

CREATE INDEX IF NOT EXISTS drone_products_field_season_idx
    ON remote_sensing.drone_products (field_season_id);
CREATE INDEX IF NOT EXISTS drone_products_type_index_idx
    ON remote_sensing.drone_products (product_type, index_code);

CREATE TABLE IF NOT EXISTS remote_sensing.drone_index_statistics (
    drone_index_statistic_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    drone_product_id UUID NOT NULL
        REFERENCES remote_sensing.drone_products (drone_product_id) ON DELETE CASCADE,
    drone_mission_id UUID NOT NULL
        REFERENCES remote_sensing.drone_missions (drone_mission_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    observation_date DATE NOT NULL,
    phenology_stage VARCHAR(32),
    index_code VARCHAR(32) NOT NULL,
    mean_value DOUBLE PRECISION,
    minimum_value DOUBLE PRECISION,
    maximum_value DOUBLE PRECISION,
    median_value DOUBLE PRECISION,
    standard_deviation DOUBLE PRECISION,
    p10_value DOUBLE PRECISION,
    p25_value DOUBLE PRECISION,
    p75_value DOUBLE PRECISION,
    p90_value DOUBLE PRECISION,
    valid_pixel_pct DOUBLE PRECISION,
    low_value_area_pct DOUBLE PRECISION,
    medium_value_area_pct DOUBLE PRECISION,
    high_value_area_pct DOUBLE PRECISION,
    change_from_previous_mission DOUBLE PRECISION,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT drone_index_statistics_range_chk
        CHECK (minimum_value IS NULL OR maximum_value IS NULL OR minimum_value <= maximum_value),
    CONSTRAINT drone_index_statistics_valid_pixel_chk
        CHECK (valid_pixel_pct IS NULL OR valid_pixel_pct BETWEEN 0 AND 100),
    CONSTRAINT drone_index_statistics_uq
        UNIQUE (drone_product_id, spatial_unit_id, observation_date)
);

CREATE INDEX IF NOT EXISTS drone_index_statistics_field_date_idx
    ON remote_sensing.drone_index_statistics (field_season_id, observation_date);
CREATE INDEX IF NOT EXISTS drone_index_statistics_index_code_idx
    ON remote_sensing.drone_index_statistics (index_code);

CREATE TABLE IF NOT EXISTS remote_sensing.satellite_features (
    satellite_feature_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    external_source_id UUID NOT NULL
        REFERENCES metadata.external_sources (external_source_id) ON DELETE RESTRICT,
    observation_date DATE NOT NULL,
    satellite_platform VARCHAR(64),
    product_version VARCHAR(64),
    index_code VARCHAR(32) NOT NULL,
    mean_value DOUBLE PRECISION,
    minimum_value DOUBLE PRECISION,
    maximum_value DOUBLE PRECISION,
    standard_deviation DOUBLE PRECISION,
    valid_pixel_pct DOUBLE PRECISION,
    cloud_cover_pct DOUBLE PRECISION,
    temporal_composite_method VARCHAR(64),
    spatial_extraction_method VARCHAR(64),
    processing_version VARCHAR(64),
    processing_run_id UUID
        REFERENCES metadata.processing_runs (processing_run_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT satellite_features_range_chk
        CHECK (minimum_value IS NULL OR maximum_value IS NULL OR minimum_value <= maximum_value),
    CONSTRAINT satellite_features_valid_pixel_chk
        CHECK (valid_pixel_pct IS NULL OR valid_pixel_pct BETWEEN 0 AND 100),
    CONSTRAINT satellite_features_cloud_chk
        CHECK (cloud_cover_pct IS NULL OR cloud_cover_pct BETWEEN 0 AND 100),
    CONSTRAINT satellite_features_uq
        UNIQUE (field_season_id, spatial_unit_id, external_source_id, observation_date, index_code, processing_version)
);

CREATE INDEX IF NOT EXISTS satellite_features_field_date_idx
    ON remote_sensing.satellite_features (field_season_id, observation_date);
CREATE INDEX IF NOT EXISTS satellite_features_source_idx
    ON remote_sensing.satellite_features (external_source_id);

-- ============================================================================
-- 9. FIELD VISITS, CROP HEALTH, IMAGES AND ANNOTATION
-- ============================================================================

CREATE TABLE IF NOT EXISTS diagnostics.field_visits (
    field_visit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    crop_instance_id UUID
        REFERENCES agronomy.crop_instances (crop_instance_id) ON DELETE SET NULL,
    visit_number INTEGER,
    visit_type VARCHAR(32) NOT NULL,
    visited_at TIMESTAMPTZ NOT NULL,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    visit_point geometry(Point, 4326),
    gps_accuracy_m DOUBLE PRECISION,
    enumerator_id_hash VARCHAR(128),
    phenology_stage VARCHAR(32),
    days_after_planting INTEGER,
    emergence_pct DOUBLE PRECISION,
    plant_population_estimate_ha DOUBLE PRECISION,
    canopy_cover_pct DOUBLE PRECISION,
    crop_height_cm DOUBLE PRECISION,
    crop_condition VARCHAR(32),
    weed_pressure VARCHAR(32),
    drought_stress_severity DOUBLE PRECISION,
    heat_stress_severity DOUBLE PRECISION,
    waterlogging_severity DOUBLE PRECISION,
    lodging_severity DOUBLE PRECISION,
    observation_confidence DOUBLE PRECISION,
    visit_completion_status VARCHAR(32) NOT NULL DEFAULT 'COMPLETE',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT field_visits_visit_number_chk CHECK (visit_number IS NULL OR visit_number > 0),
    CONSTRAINT field_visits_emergence_chk CHECK (emergence_pct IS NULL OR emergence_pct BETWEEN 0 AND 100),
    CONSTRAINT field_visits_canopy_chk CHECK (canopy_cover_pct IS NULL OR canopy_cover_pct BETWEEN 0 AND 100),
    CONSTRAINT field_visits_confidence_chk CHECK (observation_confidence IS NULL OR observation_confidence BETWEEN 0 AND 1),
    CONSTRAINT field_visits_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT field_visits_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS field_visits_field_time_idx
    ON diagnostics.field_visits (field_season_id, visited_at);
CREATE INDEX IF NOT EXISTS field_visits_point_gix
    ON diagnostics.field_visits USING GIST (visit_point);

CREATE TABLE IF NOT EXISTS diagnostics.crop_health_observations (
    crop_health_observation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_visit_id UUID NOT NULL
        REFERENCES diagnostics.field_visits (field_visit_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    crop_instance_id UUID
        REFERENCES agronomy.crop_instances (crop_instance_id) ON DELETE SET NULL,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    observed_at TIMESTAMPTZ NOT NULL,
    observation_point geometry(Point, 4326),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    gps_accuracy_m DOUBLE PRECISION,
    health_class VARCHAR(32) NOT NULL,
    disease_code VARCHAR(64),
    pest_code VARCHAR(64),
    nutrient_deficiency_code VARCHAR(64),
    climate_stress_code VARCHAR(64),
    affected_organ VARCHAR(64),
    affected_area_pct DOUBLE PRECISION,
    severity_class VARCHAR(32),
    severity_pct DOUBLE PRECISION,
    symptom_description TEXT,
    distribution_pattern VARCHAR(64),
    label_source VARCHAR(64),
    provisional_model_label VARCHAR(128),
    expert_final_label VARCHAR(128),
    expert_review_status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    reviewer_agreement VARCHAR(32),
    confidence_score DOUBLE PRECISION,
    uncertainty_reason TEXT,
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT crop_health_affected_area_chk
        CHECK (affected_area_pct IS NULL OR affected_area_pct BETWEEN 0 AND 100),
    CONSTRAINT crop_health_severity_chk
        CHECK (severity_pct IS NULL OR severity_pct BETWEEN 0 AND 100),
    CONSTRAINT crop_health_confidence_chk
        CHECK (confidence_score IS NULL OR confidence_score BETWEEN 0 AND 1),
    CONSTRAINT crop_health_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT crop_health_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS crop_health_observations_field_time_idx
    ON diagnostics.crop_health_observations (field_season_id, observed_at);
CREATE INDEX IF NOT EXISTS crop_health_observations_disease_idx
    ON diagnostics.crop_health_observations (disease_code);
CREATE INDEX IF NOT EXISTS crop_health_observations_health_class_idx
    ON diagnostics.crop_health_observations (health_class);
CREATE INDEX IF NOT EXISTS crop_health_observations_point_gix
    ON diagnostics.crop_health_observations USING GIST (observation_point);

CREATE TABLE IF NOT EXISTS diagnostics.crop_health_images (
    image_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    crop_health_observation_id UUID NOT NULL
        REFERENCES diagnostics.crop_health_observations (crop_health_observation_id) ON DELETE CASCADE,
    field_visit_id UUID NOT NULL
        REFERENCES diagnostics.field_visits (field_visit_id) ON DELETE CASCADE,
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    crop_instance_id UUID
        REFERENCES agronomy.crop_instances (crop_instance_id) ON DELETE SET NULL,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    file_path TEXT NOT NULL,
    image_type VARCHAR(32) NOT NULL,
    crop_code VARCHAR(64),
    affected_organ VARCHAR(64),
    phenology_stage VARCHAR(32),
    health_class VARCHAR(32),
    captured_at TIMESTAMPTZ NOT NULL,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    latitude_generalised DOUBLE PRECISION,
    longitude_generalised DOUBLE PRECISION,
    gps_accuracy_m DOUBLE PRECISION,
    camera_device_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    image_width_px INTEGER,
    image_height_px INTEGER,
    blur_score DOUBLE PRECISION,
    exposure_score DOUBLE PRECISION,
    background_complexity DOUBLE PRECISION,
    checksum_sha256 CHAR(64),
    label_version VARCHAR(64),
    location_access_tier VARCHAR(32) NOT NULL DEFAULT 'CONTROLLED',
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT crop_health_images_dimensions_chk CHECK (
        (image_width_px IS NULL OR image_width_px > 0)
        AND (image_height_px IS NULL OR image_height_px > 0)
    ),
    CONSTRAINT crop_health_images_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT crop_health_images_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS crop_health_images_observation_idx
    ON diagnostics.crop_health_images (crop_health_observation_id);
CREATE INDEX IF NOT EXISTS crop_health_images_field_time_idx
    ON diagnostics.crop_health_images (field_season_id, captured_at);
CREATE INDEX IF NOT EXISTS crop_health_images_checksum_idx
    ON diagnostics.crop_health_images (checksum_sha256);

CREATE TABLE IF NOT EXISTS diagnostics.annotation_reviews (
    annotation_review_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    crop_health_observation_id UUID NOT NULL
        REFERENCES diagnostics.crop_health_observations (crop_health_observation_id) ON DELETE CASCADE,
    image_id UUID
        REFERENCES diagnostics.crop_health_images (image_id) ON DELETE CASCADE,
    annotator_id_hash VARCHAR(128),
    reviewer_role VARCHAR(64),
    annotated_at TIMESTAMPTZ NOT NULL,
    label_guideline_version VARCHAR(64),
    initial_label VARCHAR(128),
    reviewed_label VARCHAR(128),
    final_label VARCHAR(128),
    severity_class VARCHAR(32),
    confidence_score DOUBLE PRECISION,
    agreement_status VARCHAR(32),
    disagreement_reason TEXT,
    escalation_status VARCHAR(32) NOT NULL DEFAULT 'NOT_REQUIRED',
    adjudicator_id_hash VARCHAR(128),
    adjudicated_at TIMESTAMPTZ,
    review_notes TEXT,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT annotation_reviews_confidence_chk
        CHECK (confidence_score IS NULL OR confidence_score BETWEEN 0 AND 1)
);

CREATE INDEX IF NOT EXISTS annotation_reviews_observation_idx
    ON diagnostics.annotation_reviews (crop_health_observation_id);
CREATE INDEX IF NOT EXISTS annotation_reviews_image_idx
    ON diagnostics.annotation_reviews (image_id);

-- ============================================================================
-- 10. HARVEST AND CROP-CUT MEASUREMENTS
-- ============================================================================

CREATE TABLE IF NOT EXISTS harvest.harvest_measurements (
    harvest_measurement_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    field_season_id UUID NOT NULL
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    crop_instance_id UUID
        REFERENCES agronomy.crop_instances (crop_instance_id) ON DELETE SET NULL,
    spatial_unit_id UUID
        REFERENCES spatial.spatial_units (spatial_unit_id) ON DELETE SET NULL,
    crop_cut_geometry geometry(Polygon, 4326),
    crop_cut_centroid geometry(Point, 4326),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    gps_accuracy_m DOUBLE PRECISION,
    harvest_date DATE NOT NULL,
    harvested_area_ha DOUBLE PRECISION,
    quadrat_area_m2 DOUBLE PRECISION,
    number_of_quadrats INTEGER,
    fresh_weight_kg DOUBLE PRECISION,
    grain_moisture_pct DOUBLE PRECISION,
    standard_moisture_pct DOUBLE PRECISION,
    adjusted_dry_weight_kg DOUBLE PRECISION,
    measured_yield_kg_ha DOUBLE PRECISION,
    farmer_reported_yield_kg_ha DOUBLE PRECISION,
    estimated_total_production_kg DOUBLE PRECISION,
    partial_loss_pct DOUBLE PRECISION,
    abandonment_status VARCHAR(32),
    complete_failure_status VARCHAR(32),
    primary_loss_reason VARCHAR(64),
    secondary_loss_reason VARCHAR(64),
    measurement_method VARCHAR(64),
    weighing_scale_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    moisture_meter_id UUID
        REFERENCES metadata.devices (device_id) ON DELETE SET NULL,
    enumerator_id_hash VARCHAR(128),
    measurement_confidence DOUBLE PRECISION,
    verification_status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    source_id UUID REFERENCES metadata.source_registry (source_id) ON DELETE SET NULL,
    quality_flag VARCHAR(32) NOT NULL DEFAULT 'PASS',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT harvest_measurements_area_chk CHECK (
        (harvested_area_ha IS NULL OR harvested_area_ha >= 0)
        AND (quadrat_area_m2 IS NULL OR quadrat_area_m2 > 0)
    ),
    CONSTRAINT harvest_measurements_quadrats_chk
        CHECK (number_of_quadrats IS NULL OR number_of_quadrats > 0),
    CONSTRAINT harvest_measurements_weights_chk CHECK (
        (fresh_weight_kg IS NULL OR fresh_weight_kg >= 0)
        AND (adjusted_dry_weight_kg IS NULL OR adjusted_dry_weight_kg >= 0)
    ),
    CONSTRAINT harvest_measurements_moisture_chk CHECK (
        (grain_moisture_pct IS NULL OR grain_moisture_pct BETWEEN 0 AND 100)
        AND (standard_moisture_pct IS NULL OR standard_moisture_pct BETWEEN 0 AND 100)
    ),
    CONSTRAINT harvest_measurements_loss_chk
        CHECK (partial_loss_pct IS NULL OR partial_loss_pct BETWEEN 0 AND 100),
    CONSTRAINT harvest_measurements_confidence_chk
        CHECK (measurement_confidence IS NULL OR measurement_confidence BETWEEN 0 AND 1),
    CONSTRAINT harvest_measurements_latitude_chk CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT harvest_measurements_longitude_chk CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE INDEX IF NOT EXISTS harvest_measurements_field_season_idx
    ON harvest.harvest_measurements (field_season_id, harvest_date);
CREATE INDEX IF NOT EXISTS harvest_measurements_crop_instance_idx
    ON harvest.harvest_measurements (crop_instance_id);
CREATE INDEX IF NOT EXISTS harvest_measurements_geometry_gix
    ON harvest.harvest_measurements USING GIST (crop_cut_geometry);

-- ============================================================================
-- 11. QUALITY AND UNCERTAINTY REGISTERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS quality.quality_flags (
    quality_flag_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(128) NOT NULL,
    entity_id VARCHAR(128) NOT NULL,
    quality_dimension VARCHAR(64) NOT NULL,
    quality_code VARCHAR(64) NOT NULL,
    severity VARCHAR(32) NOT NULL,
    rule_id VARCHAR(64),
    observed_value TEXT,
    expected_value TEXT,
    reason TEXT,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolution_action TEXT,
    resolution_status VARCHAR(32) NOT NULL DEFAULT 'OPEN',
    reviewer_id_hash VARCHAR(128),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT quality_flags_resolution_chk
        CHECK (resolution_status <> 'RESOLVED' OR resolved_at IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS quality_flags_entity_idx
    ON quality.quality_flags (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS quality_flags_status_severity_idx
    ON quality.quality_flags (resolution_status, severity);

CREATE TABLE IF NOT EXISTS quality.uncertainty_flags (
    uncertainty_flag_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(128) NOT NULL,
    entity_id VARCHAR(128) NOT NULL,
    uncertainty_type VARCHAR(64) NOT NULL,
    severity VARCHAR(32) NOT NULL,
    reason TEXT,
    uncertainty_value DOUBLE PRECISION,
    uncertainty_unit VARCHAR(32),
    source_description VARCHAR(128),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    reviewer_id_hash VARCHAR(128),
    resolution_status VARCHAR(32) NOT NULL DEFAULT 'OPEN',
    resolution_notes TEXT,
    resolved_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uncertainty_flags_resolution_chk
        CHECK (resolution_status <> 'RESOLVED' OR resolved_at IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS uncertainty_flags_entity_idx
    ON quality.uncertainty_flags (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS uncertainty_flags_type_idx
    ON quality.uncertainty_flags (uncertainty_type);

-- ============================================================================
-- 12. AI-READY FIELD-SEASON FEATURE MART
-- ============================================================================

CREATE TABLE IF NOT EXISTS features.field_season_features (
    field_season_id UUID PRIMARY KEY
        REFERENCES agronomy.field_seasons (field_season_id) ON DELETE CASCADE,
    field_id UUID NOT NULL
        REFERENCES spatial.fields (field_id) ON DELETE CASCADE,
    farm_id UUID NOT NULL
        REFERENCES spatial.farms (farm_id) ON DELETE CASCADE,
    farmer_id VARCHAR(64)
        REFERENCES governance.farmers (farmer_id) ON DELETE SET NULL,
    season_id VARCHAR(16) NOT NULL,
    district_code VARCHAR(8),
    ward_code VARCHAR(16),
    natural_region VARCHAR(8),
    field_area_ha DOUBLE PRECISION,
    average_elevation_m DOUBLE PRECISION,
    average_slope_pct DOUBLE PRECISION,
    dominant_soil_texture VARCHAR(32),
    irrigation_status VARCHAR(32),
    crop_code VARCHAR(64),
    variety_code VARCHAR(64),
    planting_date DATE,
    planting_delay_days INTEGER,
    previous_crop_code VARCHAR(64),
    farmer_experience_band VARCHAR(32),
    extension_access_status VARCHAR(32),
    mechanisation_level VARCHAR(32),
    credit_access_status VARCHAR(32),
    fertiliser_applied BOOLEAN,
    total_fertiliser_kg_ha DOUBLE PRECISION,
    irrigation_event_count INTEGER,
    management_timeliness_score DOUBLE PRECISION,
    cumulative_rainfall_mm DOUBLE PRECISION,
    maximum_dry_spell_days INTEGER,
    rainy_day_count INTEGER,
    cumulative_gdd DOUBLE PRECISION,
    heat_stress_days INTEGER,
    cold_stress_days INTEGER,
    cumulative_reference_et_mm DOUBLE PRECISION,
    cumulative_water_balance_mm DOUBLE PRECISION,
    mean_vapour_pressure_deficit_kpa DOUBLE PRECISION,
    mean_leaf_wetness_hours DOUBLE PRECISION,
    cumulative_solar_radiation_mj_m2 DOUBLE PRECISION,
    mean_uv_index DOUBLE PRECISION,
    maximum_uv_index DOUBLE PRECISION,
    mean_soil_moisture_pct DOUBLE PRECISION,
    minimum_soil_moisture_pct DOUBLE PRECISION,
    soil_moisture_variability DOUBLE PRECISION,
    mean_soil_temperature_c DOUBLE PRECISION,
    mean_soil_ph DOUBLE PRECISION,
    soil_ph_variability DOUBLE PRECISION,
    mean_soil_ec_ds_m DOUBLE PRECISION,
    mean_soil_nitrogen_mg_kg DOUBLE PRECISION,
    mean_soil_phosphorus_mg_kg DOUBLE PRECISION,
    mean_soil_potassium_mg_kg DOUBLE PRECISION,
    peak_ndvi DOUBLE PRECISION,
    mean_ndvi DOUBLE PRECISION,
    ndvi_variability DOUBLE PRECISION,
    peak_evi DOUBLE PRECISION,
    mean_evi DOUBLE PRECISION,
    mean_ndwi DOUBLE PRECISION,
    minimum_ndwi DOUBLE PRECISION,
    mean_ndsmi DOUBLE PRECISION,
    minimum_ndsmi DOUBLE PRECISION,
    low_vigour_area_pct DOUBLE PRECISION,
    low_moisture_area_pct DOUBLE PRECISION,
    field_visit_count INTEGER,
    disease_presence BOOLEAN,
    primary_disease_code VARCHAR(64),
    maximum_disease_severity_pct DOUBLE PRECISION,
    pest_presence BOOLEAN,
    maximum_pest_severity_pct DOUBLE PRECISION,
    nutrient_deficiency_presence BOOLEAN,
    drought_stress_maximum DOUBLE PRECISION,
    heat_stress_maximum DOUBLE PRECISION,
    waterlogging_maximum DOUBLE PRECISION,
    measured_yield_kg_ha DOUBLE PRECISION,
    farmer_reported_yield_kg_ha DOUBLE PRECISION,
    partial_loss_pct DOUBLE PRECISION,
    abandonment_status VARCHAR(32),
    complete_failure_status VARCHAR(32),
    primary_loss_reason VARCHAR(64),
    feature_cutoff_date DATE NOT NULL,
    record_completeness_pct DOUBLE PRECISION NOT NULL DEFAULT 0,
    overall_confidence_score DOUBLE PRECISION,
    dataset_split VARCHAR(16),
    release_version VARCHAR(32),
    processing_run_id UUID
        REFERENCES metadata.processing_runs (processing_run_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT field_season_features_completeness_chk
        CHECK (record_completeness_pct BETWEEN 0 AND 100),
    CONSTRAINT field_season_features_confidence_chk
        CHECK (overall_confidence_score IS NULL OR overall_confidence_score BETWEEN 0 AND 1),
    CONSTRAINT field_season_features_split_chk
        CHECK (dataset_split IS NULL OR dataset_split IN ('TRAIN', 'VALIDATION', 'TEST')),
    CONSTRAINT field_season_features_soil_ph_chk
        CHECK (mean_soil_ph IS NULL OR mean_soil_ph BETWEEN 0 AND 14),
    CONSTRAINT field_season_features_percentage_chk CHECK (
        (low_vigour_area_pct IS NULL OR low_vigour_area_pct BETWEEN 0 AND 100)
        AND (low_moisture_area_pct IS NULL OR low_moisture_area_pct BETWEEN 0 AND 100)
        AND (partial_loss_pct IS NULL OR partial_loss_pct BETWEEN 0 AND 100)
    )
);

CREATE INDEX IF NOT EXISTS field_season_features_season_crop_idx
    ON features.field_season_features (season_id, crop_code);
CREATE INDEX IF NOT EXISTS field_season_features_location_idx
    ON features.field_season_features (district_code, ward_code, natural_region);
CREATE INDEX IF NOT EXISTS field_season_features_split_idx
    ON features.field_season_features (dataset_split, release_version);

-- ============================================================================
-- 13. UPDATED_AT TRIGGER
-- ============================================================================

CREATE OR REPLACE FUNCTION metadata.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

DO $$
DECLARE
    table_record RECORD;
BEGIN
    FOR table_record IN
        SELECT c.table_schema, c.table_name
        FROM information_schema.columns c
        WHERE c.column_name = 'updated_at'
          AND c.table_schema IN (
              'metadata', 'governance', 'spatial', 'agronomy', 'weather',
              'soil', 'remote_sensing', 'diagnostics', 'harvest', 'quality', 'features'
          )
          AND c.table_name <> 'set_updated_at'
        GROUP BY c.table_schema, c.table_name
    LOOP
        EXECUTE format(
            'DROP TRIGGER IF EXISTS set_updated_at ON %I.%I',
            table_record.table_schema,
            table_record.table_name
        );

        EXECUTE format(
            'CREATE TRIGGER set_updated_at BEFORE UPDATE ON %I.%I '
            || 'FOR EACH ROW EXECUTE FUNCTION metadata.set_updated_at()',
            table_record.table_schema,
            table_record.table_name
        );
    END LOOP;
END;
$$;

-- ============================================================================
-- 14. TABLE AND COLUMN COMMENTS FOR CRITICAL GOVERNANCE RULES
-- ============================================================================

COMMENT ON TABLE governance.farmers IS
    'Pseudonymous analytical farmer records. Direct identifiers must not be stored here.';
COMMENT ON TABLE governance.consent_registry_restricted IS
    'Restricted personally identifiable information and consent records. Apply separate access controls.';
COMMENT ON TABLE governance.farmer_farm_roles IS
    'Many-to-many relationship between farmers and farms, including role and decision responsibilities.';
COMMENT ON TABLE soil.rover_measurements IS
    'Point-level soil rover observations including moisture, temperature, pH, EC, nitrogen, phosphorus and potassium.';
COMMENT ON TABLE features.field_season_features IS
    'One-row-per-field-season modelling table. Detailed source records must remain available for traceability.';
COMMENT ON COLUMN harvest.harvest_measurements.measured_yield_kg_ha IS
    'Yield derived from measured crop-cut observations.';
COMMENT ON COLUMN harvest.harvest_measurements.farmer_reported_yield_kg_ha IS
    'Yield reported by the farmer; must remain separate from measured yield.';

COMMIT;

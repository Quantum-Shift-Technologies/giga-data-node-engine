# Changelog

## 0.1.0 — 2026-07-29

- Initial representative sample release.
- Added raw weather, soil rover, drone, crop-health, geometry and harvest records.
- Added processed summaries, NDVI raster and field-season feature table.
- Added metadata, schema, validation, naming and versioning documentation.

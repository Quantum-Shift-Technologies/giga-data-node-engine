# GigaData Engine representative sample

This package demonstrates sample records, layers, formats, identifiers, naming rules, validation records and release versioning for GigaData Engine.

- Dataset ID: `GDE-ZW-AGR-2026-0001`
- Release: `0.1.0`
- Schema: `2.0.0`
- Status: **synthetic representative sample**

## Layering

1. `raw/` preserves original observations and files.
2. `processed/` contains validated, calibrated, standardised and aggregated assets.
3. `features/` contains one model-ready record per field-season.

The package is intentionally small and must not be used as a real agricultural dataset.

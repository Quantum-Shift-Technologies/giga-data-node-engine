# Annotation guideline

Machine-assisted labels remain provisional until human expert verification.

# Reviewer workflow

Enumerator label → agronomist review → adjudication when reviewers disagree → final label release.

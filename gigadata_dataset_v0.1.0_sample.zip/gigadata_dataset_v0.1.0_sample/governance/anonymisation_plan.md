# Anonymisation plan

- Use pseudonymous `farmer_id` values in analytical data.
- Keep names, phone numbers and identity references in a separate restricted registry.
- Generalise coordinates for open/public tiers.
- Hash enumerator, operator and reviewer identifiers.
- Remove direct identifiers before dataset release.

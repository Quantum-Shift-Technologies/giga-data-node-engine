# Access policy

- **Public generalised:** aggregated features and generalised locations.
- **Controlled research:** field-level records under an approved data-use agreement.
- **Restricted:** consent registry, direct identifiers and precise sensitive coordinates.

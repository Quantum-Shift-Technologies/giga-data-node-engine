# Responsible use

Do not use this demonstration sample for real farmer decisions, insurance pricing or production forecasting.

# Demonstration licence

This synthetic representative sample is for demonstration and evaluation only.

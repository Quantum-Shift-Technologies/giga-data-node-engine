# Dataset card

## Purpose
Demonstrate how GigaData packages agricultural observations and AI-ready data assets.

## Contents
One synthetic farmer, farm, field, field-season, weather station, soil rover run, drone mission, crop-health observation and harvest measurement.

## Intended uses
Architecture review, demonstrations, data-contract testing and handover-format validation.

## Prohibited uses
Real agronomic recommendations, underwriting, credit decisions, production forecasts or research conclusions.
